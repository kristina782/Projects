package knjige;

public enum Period {
	DNEVNO, SEDMICNO, MESECNO, TROMESECNO, SESTOMESECNO, GODISNJE;
}
