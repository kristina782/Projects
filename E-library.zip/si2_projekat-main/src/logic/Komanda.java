package logic;

public interface Komanda {
	void execute();
}
